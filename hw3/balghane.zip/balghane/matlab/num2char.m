function [char] = num2char(num)
if num == 1
    char = 'a';
elseif num == 2
    char = 'b';
elseif num == 3
    char = 'c';
elseif num == 4
    char = 'd';
elseif num == 5
    char = 'e';
elseif num == 6
    char = 'f';
elseif num == 7
    char = 'g';
elseif num == 8
    char = 'h';
elseif num == 9
    char = 'i';
elseif num == 10
    char = 'j';
elseif num == 11
    char = 'k';
elseif num == 12
    char = 'l';
elseif num == 13
    char = 'm';
elseif num == 14
    char = 'n';
elseif num == 15
    char = 'o';
elseif num == 16
    char = 'p';
elseif num == 17
    char = 'q';
elseif num == 18
    char = 'r';
elseif num == 19
    char = 's';
elseif num == 20
    char = 't';
elseif num == 21
    char = 'u';
elseif num == 22
    char = 'v';
elseif num == 23
    char = 'w';
elseif num == 24
    char = 'x';
elseif num == 25
    char = 'y';
elseif num == 26
    char = 'z';
elseif num == 27
    char = '0';
elseif num == 28
    char = '1';
elseif num == 29
    char = '2';
elseif num == 30
    char = '3';
elseif num == 31
    char = '4';
elseif num == 32
    char = '5';
elseif num == 33
    char = '6';
elseif num == 34
    char = '7';
elseif num == 35
    char = '8';
elseif num == 36
    char = '9';
end